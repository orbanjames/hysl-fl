from hysl_fl.llm.prompt_templates import HYSL_PROMPT

class HybridReasoningPipeline:
    def __init__(self, llm):
        self.llm = llm
    def run(self, encoded):
        return self.llm.analyze(HYSL_PROMPT.format(evidence=encoded))
