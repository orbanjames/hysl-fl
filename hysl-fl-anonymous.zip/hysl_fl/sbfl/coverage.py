class CoverageMatrix:
    def __init__(self):
        self.matrix = {}
        self.test_results = {}
