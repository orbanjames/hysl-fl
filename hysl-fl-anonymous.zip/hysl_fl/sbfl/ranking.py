from .metrics import ochiai

def compute_ranking(coverage):
    ranking = []
    total_failed = sum(not p for p in coverage.test_results.values())
    for element, tests in coverage.matrix.items():
        fe = sum(executed and not coverage.test_results[t] for t, executed in tests.items())
        pe = sum(executed and coverage.test_results[t] for t, executed in tests.items())
        ranking.append((element, ochiai(fe, pe, total_failed)))
    return sorted(ranking, key=lambda x: x[1], reverse=True)
