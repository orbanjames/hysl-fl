import math

def ochiai(failed_exec, passed_exec, total_failed):
    if failed_exec == 0:
        return 0.0
    return failed_exec / math.sqrt(total_failed * (failed_exec + passed_exec))
