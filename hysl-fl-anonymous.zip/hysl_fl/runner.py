def run_hysl_fl(coverage, llm):
    from hysl_fl.sbfl.ranking import compute_ranking
    from hysl_fl.encoder.spectrum_encoder import SpectrumEncoder
    from hysl_fl.reasoning.hybrid_pipeline import HybridReasoningPipeline
    ranking = compute_ranking(coverage)
    encoded = SpectrumEncoder().encode(ranking)
    return HybridReasoningPipeline(llm).run(encoded)
