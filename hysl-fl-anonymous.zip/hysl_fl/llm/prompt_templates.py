HYSL_PROMPT = """Analyze the following SBFL evidence:\n{evidence}"""
